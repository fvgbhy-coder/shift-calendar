package com.example.shiftcalendar

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val anchorDate = LocalDate.of(2026, 11, 24)
private val cycle = listOf("주간", "야간", "비번", "휴무")

private fun shiftFor(date: LocalDate): String {
    // 기준일(2026-11-24)은 주야비휴 순서 중 두 번째인 야간(index 1).
    val offset = ChronoUnit.DAYS.between(anchorDate, date).toInt()
    return cycle[Math.floorMod(offset + 1, cycle.size)]
}

private fun shiftColor(shift: String): Color = when (shift) {
    "주간" -> Color(0xFF2878D0)
    "야간" -> Color(0xFFE58B24)
    "비번" -> Color(0xFF778397)
    else -> Color(0xFF26966B)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShiftCalendarApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftCalendarApp() {
    var shownMonth by remember { mutableStateOf(YearMonth.of(2026, 11)) }
    var selectedDate by remember { mutableStateOf(LocalDate.of(2026, 11, 24)) }
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("shift_calendar", Context.MODE_PRIVATE) }
    var customShifts by remember {
        mutableStateOf(
            prefs.all.filterKeys { it.startsWith("shift_") }
                .mapNotNull { (key, value) ->
                    runCatching { LocalDate.parse(key.removePrefix("shift_")) to (value as String) }.getOrNull()
                }.toMap()
        )
    }
    var notes by remember {
        mutableStateOf(
            prefs.all.filterKeys { it.startsWith("note_") }
                .mapNotNull { (key, value) ->
                    runCatching { LocalDate.parse(key.removePrefix("note_")) to (value as String) }.getOrNull()
                }.toMap()
        )
    }
    var showEdit by remember { mutableStateOf(false) }
    var showNote by remember { mutableStateOf(false) }
    var noteDraft by remember { mutableStateOf("") }

    fun saveShift(date: LocalDate, shift: String?) {
        customShifts = if (shift == null) customShifts - date else customShifts + (date to shift)
        prefs.edit().apply {
            if (shift == null) remove("shift_$date") else putString("shift_$date", shift)
        }.apply()
    }
    fun saveNote(date: LocalDate, note: String) {
        notes = if (note.isBlank()) notes - date else notes + (date to note)
        prefs.edit().apply {
            if (note.isBlank()) remove("note_$date") else putString("note_$date", note)
        }.apply()
    }

    val selectedShift = customShifts[selectedDate] ?: shiftFor(selectedDate)
    val today = LocalDate.now()
    val firstDay = shownMonth.atDay(1)
    // Sunday-first calendar
    val leading = firstDay.dayOfWeek.value % 7
    val cells = buildList<LocalDate?> {
        repeat(leading) { add(null) }
        for (day in 1..shownMonth.lengthOfMonth()) add(shownMonth.atDay(day))
        while (size % 7 != 0) add(null)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF183B63),
            secondary = Color(0xFF3978B8),
            background = Color(0xFFF5F7FA),
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("교대근무 캘린더", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            containerColor = Color(0xFFF5F7FA)
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF18304D)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("선택한 날짜", color = Color(0xFFB8C8DB), fontSize = 13.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            selectedDate.format(DateTimeFormatter.ofPattern("yyyy년 M월 d일")),
                            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.background(shiftColor(selectedShift), RoundedCornerShape(9.dp))
                                    .padding(horizontal = 15.dp, vertical = 8.dp)
                            ) {
                                Text(selectedShift, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (selectedDate == anchorDate) "기준 근무일" else "주야비휴 자동 계산",
                                color = Color(0xFFD5DFEA), fontSize = 13.sp
                            )
                            Spacer(Modifier.weight(1f))
                            TextButton(onClick = { showEdit = true }) {
                                Text("근무 변경", color = Color.White)
                            }
                        }
                        Spacer(Modifier.height(7.dp))
                        Text(
                            notes[selectedDate]?.let { "메모: $it" } ?: "등록된 개인 일정/메모 없음",
                            color = Color(0xFFD5DFEA), fontSize = 12.sp
                        )
                        TextButton(onClick = {
                            noteDraft = notes[selectedDate] ?: ""
                            showNote = true
                        }) { Text("일정·메모 편집", color = Color.White) }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shownMonth = shownMonth.minusMonths(1) }) {
                        Text("‹", fontSize = 30.sp, color = Color(0xFF183B63))
                    }
                    Text(
                        "${shownMonth.year}년 ${shownMonth.monthValue}월",
                        modifier = Modifier.weight(1f),
                        fontSize = 21.sp, fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { shownMonth = shownMonth.plusMonths(1) }) {
                        Text("›", fontSize = 30.sp, color = Color(0xFF183B63))
                    }
                }

                Row(Modifier.fillMaxWidth()) {
                    listOf("일", "월", "화", "수", "목", "금", "토").forEachIndexed { i, day ->
                        Text(
                            day, modifier = Modifier.weight(1f),
                            color = if (i == 0) Color(0xFFD34B4B) else if (i == 6) Color(0xFF2878D0) else Color.Gray,
                            fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                        )
                    }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(7),
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(7.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(cells) { date ->
                        if (date == null) {
                            Spacer(Modifier.height(67.dp))
                        } else {
                            val shift = customShifts[date] ?: shiftFor(date)
                            val isSelected = date == selectedDate
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(67.dp)
                                    .background(
                                        if (isSelected) Color(0xFFDCE9F7) else Color.White,
                                        RoundedCornerShape(11.dp)
                                    )
                                    .clickable {
                                        selectedDate = date
                                    }
                                    .padding(top = 7.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    date.dayOfMonth.toString(),
                                    color = if (date == today) Color(0xFFCE4545) else Color(0xFF263445),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                Spacer(Modifier.height(5.dp))
                                Box(
                                    Modifier.background(shiftColor(shift), RoundedCornerShape(5.dp))
                                        .padding(horizontal = 5.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        shift.take(1),
                                        color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("주간", "야간", "비번", "휴무").forEach { shift ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).background(shiftColor(shift), RoundedCornerShape(50)))
                            Spacer(Modifier.width(4.dp))
                            Text(shift, fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
                Text(
                    "기준: 2026.11.24 야간  ·  주야비휴 반복",
                    color = Color.Gray, fontSize = 11.sp
                )
            }
        }

        if (showEdit) {
            AlertDialog(
                onDismissRequest = { showEdit = false },
                title = { Text("${selectedDate.monthValue}월 ${selectedDate.dayOfMonth}일 근무 변경") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        cycle.forEach { shift ->
                            OutlinedButton(
                                onClick = {
                                    saveShift(selectedDate, shift)
                                    showEdit = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(shift) }
                        }
                        TextButton(
                            onClick = {
                                saveShift(selectedDate, null)
                                showEdit = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("자동 계산값으로 되돌리기") }
                    }
                },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { showEdit = false }) { Text("닫기") } }
            )
        }

        if (showNote) {
            AlertDialog(
                onDismissRequest = { showNote = false },
                title = { Text("개인 일정 및 메모") },
                text = {
                    OutlinedTextField(
                        value = noteDraft,
                        onValueChange = { noteDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("예: 아이 학교 상담, 병원, 약속") },
                        minLines = 3,
                        maxLines = 5
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        saveNote(selectedDate, noteDraft)
                        showNote = false
                    }) { Text("저장") }
                },
                dismissButton = {
                    TextButton(onClick = { showNote = false }) { Text("취소") }
                }
            )
        }
    }
}
